document.write("<h2>");
document.write(asignatura.titulacion);
document.write("</h2>");