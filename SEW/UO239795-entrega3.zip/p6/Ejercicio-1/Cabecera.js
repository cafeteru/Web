var asignatura = new Object();
asignatura.nombre = "Software y estándares en la Web";
asignatura.titulacion = "Grado en Ingeniería Informática del Software";
asignatura.centro = "Escuela de Ingeniería Informática";
asignatura.universidad = "Universidad de Oviedo";
asignatura.curso = "2017-18";
asignatura.alumno = "Iván González Mahagamage";
asignatura.email = "uo239795@uniovi.es";