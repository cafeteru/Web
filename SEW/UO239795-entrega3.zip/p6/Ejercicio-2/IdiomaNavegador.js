document.write("<h2>");
document.write("Idioma: " + infoNavegador.idioma);
document.write("</h2>");