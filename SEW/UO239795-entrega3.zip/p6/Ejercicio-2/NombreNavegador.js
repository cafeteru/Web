document.write("<h1>");
document.write("Nombre: " + infoNavegador.nombre);
document.write("</h1>");